/*
   Documentation
Name : T.Lakshminarayana
Date :28/02/2024
Title :To implement your own isalnum() function
Sample input :Enter the character: a
              
Sample output :The character 'a' is an alnum character.
*/
#include <stdio.h>

int isalpha_custom(char c) 
{
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

int isdigit_custom(char c) 
{
    return c >= '0' && c <= '9';
}

int isalnum_custom(char c)
{
    return isalpha_custom(c) || isdigit_custom(c);
}

int main() {
    char input_char;

    scanf("%c", &input_char);

    if (isalnum_custom(input_char)) 
    {
        printf("Entered character is alphanumeric character\n");
    } 
    else 
    {
        printf("Entered character is not alphanumeric character\n");
    }


    return 0;
}
