//
/*
NAME : T.Lakshminarayana
DATE : 15/02/2024
TITLE : WAP to find which day of the year.
SAMPLE INPUT : Enter the 'n' value for Array A: 5
Enter the 'n' value for Array B: 5

Enter the elements one by one for Array A: 3 2 8 5 4
Enter the elements one by one for Array B: 12 3 7 8 5

SAMPLE OUTPUT : Median of array1 : 4
Median of array2 : 7
Median of both arrays : 5.5    
*/

#include <stdio.h>
int main()
{
    //initialize variables
    int i, j, size1, size2,temp;
    float median, median1, median2;
    
    //take the size of array from the user
    printf ("Enter a number 'size1':");
    scanf ("%d", &size1);
    printf ("Enter a number 'size2':");
    scanf ("%d", &size2);
    
    //declare array using size
    int arr1[size1];
    int arr2[size2];

    //loop to get the element of an array1
    printf ("enter element in first array\n");
    for (i=0 ; i<size1 ; i++)
    {
        scanf ("%d", &arr1[i]);
    }

    //loop for getting the element of array2
    printf ("enter element in second array\n");
    for (i=0 ; i<size2 ; i++)
    {
        scanf ("%d", &arr2[i]);
    }

    //loop for sorting an unsorted array1
    for (i=0 ; i<size1 ; i++)
    {
        for (j=i+1 ; j<size1 ; j++)
        {
            if (arr1[i] > arr1[j])
            {
                temp=arr1[i];
                arr1[i]=arr1[j];
                arr1[j]=temp;
            }

        }
    }
   
    //loop for sorinting an unsorted array2
    for (i=0 ; i<size2 ; i++)
    {
        for (j=i+1 ; j<size2 ; j++)
        {
            if (arr2[i] > arr2[j])
            {
                temp=arr2[i];
                arr2[i]=arr2[j];
                arr2[j]=temp;
            }
        }
    }

    //condition to get the median of array1
    if (size1 % 2 != 0)
    {
       median1=(float) arr1[size1/2];
    }
    else
    {
        median1=(float) (arr1[(size1-1)/2] + arr1[size1/2])/2;
        
    }
    printf ("median of array1 : %g\n", median1);
   
    //condition to get the median of array2
    if (size2 % 2 != 0)
    {
        median2=(float)(arr2[size2/2]);
    }
    else
    {
        median2=(float) (arr2[(size2-1)/2] + arr2[size2/2])/2;
    }
    printf ("median of array2 : %g\n", median2);

    //median of both array
    median=(float)(median1+median2)/2;
    printf ("Median of both arrays : %g\n", median);
    
   return 0;
}