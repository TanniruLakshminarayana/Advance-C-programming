/*
   Documentation
Name : T.Lakshminarayana
Date :05/03/2024
Title:
      To count no. of characters, words and lines, entered through stdin
Sample input :Hello world
              Dennis Ritchie
              Linux
Sample output :Character count : 33
               Line count : 3
               Word count : 5
*/

#include<stdio.h>
#include<ctype.h>

int main()
{
    int characterCount=0,wordCount=0,lineCount=0;
    /* Flag to track if the current character is inside a word*/
    int inWord=0;

    int c;
    while((c=getchar())!=EOF)
    {
        characterCount++;
        /*Check for new line*/
        if(c=='\n')
        {
            lineCount++;
        }
         /* Check for word boundary*/
        if (isspace(c))
        {
            inWord = 0;
        }
        else
        {

            /*If not in a word, increment word count*/
            if (!inWord)
            {
                inWord = 1;
                wordCount++;
            }
        }
    }

    /*Print the results*/
    printf("\nCharacter count: %d\n", characterCount);
    printf("Line count: %d\n", lineCount);
    printf("Word count: %d\n", wordCount);

    return 0;
}