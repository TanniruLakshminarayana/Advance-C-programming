#!/bin/bash
<<doc
Name : Lakshminarayana
Date : 17/01/2024
Description : To replace 20% lines in a .c file randomly and replace it with the pattern
Sample Input :1. ./replace_DEL.sh main.c
              2. ./replace_DEL.sh
Sample Output :1. Before replacing
                  #incude <stdio.h>
                  int main()
                  {
                        printf(“Hello world\n”);
                  }
                  After replacing
                  #incude <stdio.h>
                  int main()
                  {
                        <-----------Deleted------------>
                  }
                2.Error : Please pass the file name through command line.
doc
#displaying file content before running the loop
echo "Before replacing"
cat $1
if [ $# -gt 0 ]   #checking weather the file name is passed through the cla
then
    if [ -f $1 ]   #checking weather the file is present or not
    then
        if [ -s $1 ] #checking weather the file contains any content or not
        then
            line=`cat $1 | wc -l` #to get the line count of a given file
            if [ $line -ge 5 ]
            then
                a=`expr $line / 5` # to get 20% based on the number of lines in a file
                arr=(`shuf -i 1-$line -n$a`) #to get random line numbers in a given range
                for i in ${arr[@]}
                do
                   sed -i "$i s/.*/<-----------Deleted------------>/g" $1
               done
               echo "After replacing"
              cat $1
          else
              echo "Error : The file must contains greater than 5 lines"
            fi
        else
              echo "Error : $1 is empty file. So can’t replace the string."
        fi
    else
        echo "Error : No such a file."
    fi
else
    echo "Error : Please pass the file name through command line."
fi