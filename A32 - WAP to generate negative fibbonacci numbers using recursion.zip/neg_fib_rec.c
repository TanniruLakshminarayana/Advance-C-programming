/*
   Documentation
Name : T.Lakshminarayana
Date :06/03/3024
Title :To generate negative fibbonacci numbers using recursion
Sample input :Enter a number: -8

Sample output :0, 1, -1, 2, -3, 5, -8
*/


#include <stdio.h>

void negative_fibonacci(int limit, int first, int second, int next)
{
    printf("%d, ",next);
    first=second;
    second=next;
    next=first-second;
    if(next>=limit && next<=-limit)
    {
        negative_fibonacci(limit, first, second, next);
    }
}

int main()
{
    int limit;

    printf("Enter the limit : ");
    scanf("%d", &limit);
    if(limit>0)
    {
        printf("Invalid input\n");
        return 1;
    }

    negative_fibonacci(limit, 0, 1, 0);
    return 0;
}