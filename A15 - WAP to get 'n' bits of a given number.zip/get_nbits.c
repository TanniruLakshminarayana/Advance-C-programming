
/*
   Documentation
Name : T.Lakshminarayana
Date :28/02/2024
Title :To get 'n' bits of a given number
Sample input :Enter the number: 10
              Enter number of bits: 3
Sample output :Result = 2
*/

#include <stdio.h>
// Function to get 'n' bits of a given number
int get_nbits(int num, int n)
{
    // Create a mask with 'n' bits set to 1
    // Shift the mask to the right by 'n' places
    int mask=(1<<n)-1;
     // Perform a bitwise AND operation with the given number
    return num&mask;

}

int main()
{
    // Get the number and number of bits from the user
    int num, n, res = 0;

    printf("Enter num and n:");
    scanf("%d%d", &num, &n);
    // Call the function to get 'n' bits of the given number
    res = get_nbits(num, n);
    // Print the result
    printf("Result = %d\n", res);

    return 0;
}