/*
   Documentation
Name : T.Lakshminarayana
Date :11/04/2024
Title :  To generate a n*n magic square
Sample input :Enter a number: 3
Sample output :8      1      6
               3      5      7
               4      9      2

*/


#include <stdio.h>
#include <stdlib.h>

void magic_square(int n)
{
    int **magic_square = (int **)calloc(n, sizeof(int *));
    for (int i = 0; i < n; i++)
    {
        magic_square[i] = (int *)calloc(n, sizeof(int));
    }

    int num = 1;
    int row = 0;
    int col = n / 2;

    while (num <= n * n)
    {
        magic_square[row][col] = num;
        num++;
        row--;
        col++;
        if (row == -1 && col == n)
        {
            row = 1;
            col = n - 1;
        } else if (row == -1)
        {
            row = n - 1;
        } else if (col == n)
        {
            col = 0;
        } else if (magic_square[row][col] != 0)
        {
            row += 2;
            col--;
        }
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("%-6d", magic_square[i][j]);
        }
        printf("\n");
    }

    // Free dynamically allocated memory
    for (int i = 0; i < n; i++)
    {
        free(magic_square[i]);
    }
    free(magic_square);
}

int main()
{
    int n;
    scanf("%d", &n);

    if (n <= 0 || n % 2 == 0)
    {
        printf("Error : Please enter only positive odd numbers.\n");
        return 1;
    }

    magic_square(n);

    return 0;
}