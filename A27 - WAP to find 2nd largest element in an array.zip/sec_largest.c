/*
   Documentation
Name : T.Lakshminarayana
Date :04/03/2024
Title :To find 2nd largest element in an array
Sample input :Enter the size of the Array : 5
              Enter the elements into the array: 5 1 4 2 8
Sample output :Second largest element of the array is 5
*/


#include <stdio.h>

int sec_largest(int arr[], int size)
{
    int first,second,MIN;
    first=second=MIN;
    for (int i=0; i<size; i++)
    {
       if (arr[i]>first)
       {
          second=first;
         first=arr[i];
       }
       else if (arr[i]>second && arr[i] <first)
       {
           second=arr[i];
       }
    }
    return second;
}


int main()
{
    int size, ret;

    //Read size from the user
    scanf("%d", &size);

    int arr[size];

    //Read elements into the array
    for(int i=0;i<size;i++)
    {
        scanf("%d",&arr[i]);
    }

    //funtion call
    ret = sec_largest(arr, size);

    printf("Second largest element of the array is %d\n", ret);
    return 0;
}