/*
   Documentation
Name : T.Lakshminarayana
Date :01/02/2024
Title :To generate negative Fibonacci numbers
Sample input :Enter a number: -8
Sample output :0 1 -1 2 -3 5 -8
*/

#include<stdio.h>
int main()
{
    int num;                 //initializing num variable
   // printf ("Enter a number : ");   //ask the user to enter a number
    scanf ("%d", &num);             //store the input in num variable
    if ( num <= 0)                  // check if the input is less than or equal to 0
    {
        
        int t1 = 0 ;             // initializing first variable
        int t2 = 1 ;            // initializing second variable
        printf ("%d %d ", t1, t2) ;  //print the first and second number
        int t3 = t1 - t2 ;        //initailizing next variable
        while ( t3>=num && t3<=-num )             //while next is greater than or equal to 0 and next less than equal to -num 
        {
            printf ("%d ", t3) ;         // ptint next variable
            t1=t2;
            t2=t3;
            t3=t1-t2; 
        }
    }
    else
    {
        printf ("Invalid input");    //if the input is in + then printf the error massage
    }
 return 0;
}
