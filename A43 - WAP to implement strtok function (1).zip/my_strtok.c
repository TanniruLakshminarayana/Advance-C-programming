/*
   Documentation
Name : T.Lakshminarayana
Date :10/04/2024
Title :To implement strtok function
Sample input :Enter string1 : Bangalore;;::---Chennai:;Kolkata:;Delhi:-:              Mumbai
              Enter string2 : ;./-:
Sample output :Tokens :
               Bangalore
               Chennai
               Kolkata
               Delhi
               Mumbai
*/



#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
//defining the function
char *my_strtok(char str[], const char delim[])
{
    //declaration and defination of required variables
    static char *token;
    static int index = 0 ;
    //storing index value in start_position every time
    int start_pos = index,j;
    //checking the condition that sending str is not null
    if( str != NULL )
    {
        //then copy that string address to another string address called token
        token = str;
    }
    //running while loop to compare given string upto end
    while ( token[index] != '\0' )
    {
        //making j 0 
        j = 0;
        //running while loop to compare the first string with second string 
        while( delim[j] != '\0' )
        {
            //checking the condition that the any charecter matched
            if( token[index] == delim[j] )
            {
                //if matched then make that position to null
                token[index] = '\0';
                //after making that position null increment index value 
                index++;
                //returning the address of the startposition charecter in string
                return &token[start_pos];
            }
            //increment the j
            j++;
        }
        //increment the index
        index++;
    }
    //checking the condition that if the start position is null
    if( token[start_pos] == '\0' )
    {
        //then return null
        return NULL;
    }
    //if the above condition not satisfied
    else
        //then return the address of the startposition charecter
        return &token[start_pos];
}
int main()
{
    //declaring the required strings 
    char str[50], delim[50];
    //printing a message to user
    printf("Enter the string  : ");
    //reading user input string str
    scanf("%s", str);
    //to clear all the stdout buffers
    __fpurge(stdout);
    //printing a message to user
    printf("Enter the delimeter : ");
    //reading user input string delim
    scanf("\n%s", delim);
    //to clear all the stdout buffers
    __fpurge(stdout);
    //calling the function for first time with passing str and delim and storing result in charecter pointer
    char *token = my_strtok(str, delim);
    //printing a required message in output
    printf("Tokens :\n");
    //running the while loop to call the function untill the end of string
    while (token)
    {
        //checking the condition if the charecter inside the token  is not null
        if(*token != '\0' )
        {
            //if not null then print that token
            printf("%s\n", token);
        }
        //calling the function untill comes out of the while loop
        token = my_strtok(NULL, delim);
    }
return 0;
}