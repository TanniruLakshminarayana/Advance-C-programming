/*
   Documentation
Name : T.Lakshminarayana
Date :11/04/2024
Title : To print all possible combinations of given string.
Sample input :Enter a string: abc
Sample output :All possible combinations of given string :abc
               acb
               bca
               bac
               cab
               cba
*/




#include<stdio.h>
//defining a function called swap
void swap(char *c1,char *c2)
{
    //declaring the temp and storing the value inside the c1
    char temp = *c1;
    //stoiring vale inside c2 in c1
    *c1 = *c2;
    //storing temp value in c2 
    *c2 = temp;
}
//defining the combination function
void combination(char str[],int start,int end)
{
    //declaring the required varibles
    int i;
    //checking the condition that start of string is end of the string
    if( start == end )
    {
        //then print the string
        printf("%s\n",str);
    }
    //if the above condition is not true
    else
    {
        //run a for loop upto end of string
        for ( int i = start ; i <= end ; i++ )
        {
            //calling the function swap 
            swap(str + start,str + i);
            //calling the function recursively 
            combination(str,start+1,end);
            //calling the function swap again to restore the given string
            swap(str + start,str + i );
        }
    }
}
//defining the my_strlen function to find the string length
int my_strlen(char *str)
{
    //initialising the required varibles
    int i = 0;
    //running while loop upto null charecter
    while( str[i] != '\0' )
    {
        //incremeenting i every time
        i++;
    }
    //return the i value
    return i;
}
int main()
{
    //declare the required string
    char str[100];
    //declaring and initialising the required varibles
    int n , i = 0;
    int res , count = 0;
    //printing a message to user
    printf("Enter a string : ");
    //reading user input string 
    scanf("%100[^\n]",str);
    //running while  loop upto null
    while ( str[i] != '\0' )
    {
        //checking the condition that any character of the string is same
        if( str[i] == str[i+1] )
        {
            //if same increase the count variables
            count++;
        }
        //incrementing i for runninhg while loop
        i++;
    }
    //checking the condition that count is 0
    if( count == 0 )
    {
        printf("Enter a string : ");
        //if the condition is true then call the function to find length
        n = my_strlen(str);
        //printing a message to user
        printf("All possible combinations of given string : ");
        //call the function to print the required combinations
        combination(str,0,n-1);
    }
    //if the above condition is wrong
    else
    {
        //print the error message 
        printf("Error: please enter distinct characters.");
    }
return 0;
}
