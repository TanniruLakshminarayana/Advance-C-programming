/*
   Documentation
Name : T.Lakshminarayana
Date :10/04/2024
Title :Generate consecutive NRPS of length n using k distinct character
Sample input :Enter the number characters C : 3
              Enter the Length of the string N : 6
              Enter 3 distinct characters : a b c
Sample output :Possible NRPS is abcbca
*/



#include <stdio.h>

//function declaration
void nrps(char [], int, int);

int main()
{
    //read the number of characters fron the user
    int C;
    printf("Enter the number characters C : ");
    scanf("%d", &C);
    
    //read the length of the output string from the user
    int N;
    printf("Enter the Length of the string N :");
    scanf("%d", &N);
    
    //declare the character array
    char arr[100];
    
    //read the characters from the user
    printf("Enter %d distinct characters : ", C);
    for(int i = 0; i < C; i++)
    {
        scanf(" %c", &arr[i]);
    }
    
    //declaring the flag and initializing with 1
    int flag = 1;
    
    //running the for loop to check whether the given characters are equal or not and changing the flag value based on the condition
    for(int i = 0;  i < C; i++)
    {
        for(int j =i+1; j < C; j++)
        {
            if(arr[i] == arr[j])
            {
                flag = 0;
                break;
            }
            
        }
    }
    //if flag is equal to 1 then call the function 
    if(flag == 1)
    {
        nrps(arr, C, N);
        
        //checking whether the output is NRPS or not by running the loop
        int count = 0;
        for(int i = 0; i < N; i++)
        {
            if(arr[i] == arr[C+i])
            {
                count++;
            }
            else
            {
                count = 0;
            }
        }
        //printing the output
        if(count == 0 && N <= C*C)
        {
            printf("Possible NRPS is %s", arr);
            
        }
        else
        {
            printf("Non NRPS");
        }
    }
    //if the flag value is 0 it will print error
    else
    {
        printf("Error : Enter distinct characters");
    }
        
}
//doing the operation to get the NRPS for the given input
void nrps(char arr[], int C, int N)
{
    int i, j = 0, k = 1;
    for( i = 0; i < N; i++)
    {
        if(i != (k*C)-1)
        {
            arr[C+i] = arr[i+1];
        }
        else
        {
            arr[C+i] = arr[j*C];
            j++;
            k++;
        }
    }
    arr[i]='\0';
}