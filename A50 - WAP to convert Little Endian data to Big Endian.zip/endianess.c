/*
   Documentation
Name : T.Lakshminarayana
Date :11/04/2024
Title :To convert Little Endian data to Big Endian
Sample input :Enter the size: 2
              Enter any number in Hexadecimal: ABCD
Sample output :After conversion CDAB
*/


#include<stdio.h>
int main()
{
    //initialize int size,num
    int size, num;
    //printing the entered size
    printf("Enter the size: ");
    //storing the string
    scanf("%d",&size);
    //printing the statement
    printf("Enter any number in Hexadecimal: ");
    //check the condition if size is equal to 2 or not  
    if(size == 2)
    {
        //declare short int num;
        short int num;
        //storing the num in hexadecimal form
        scanf("%hX",&num);
        //storing the address of num with type casting
        char *p = (char *)&num;
        //storing the value of *(p + 0) in char temp
        char temp = *(p + 0);
        //swaping the value
        *(p + 0) = *(p + 1);
        //swaping the value and store in temp
        *(p+1)=temp;
        //printing the statement
        printf("After conversion %hX",num);
    }
    //check the condition if size is equal to 4 or not
    
    else if(size == 4)
    {
        //storing the address of num in char *p with type casting
        char *p = (char *)&num;
        //storing the num
         scanf("%X",&num);
         //store the value in temp1
        char temp1 = *p;
        //swaping the value
        *p = *(p + 3);
        //storing the value of *(p+3) in temp1
        *(p + 3) = temp1;
        //swaping the value
         temp1 = *(p + 1);
         //swaping the value
        *(p + 1) = *(p + 2);
        //swaping the value in store in temp value
        *(p + 2) = temp1;
        //printing the statement
        printf("After conversion %X",num);
}
}