/*
   Documentation
Name : T.Lakshminarayana
Date :08/02/2024
Title :WAP to print the numbers in X format as shown below
Sample input :Enter the number: 4
Sample output :
1  4
 23
 23
1  4
*/

#include <stdio.h>

int main()
{
    //Declare the variables
        int i,j,num,count;
    //Prompt user input
        printf("enter the number:");
        scanf("%d",&num);
    count = num;
 //Check for condition to print the x pattern
    for (i = 1; i <= count; i++) {
        for (j =1; j <= count; j++) {
            if (j == i || (i+j==num+1)) {
                printf("%d", j);
            }
            else {
                printf(" ");
            }
        }

        printf("\n");
    }
 //Exit successful
    return 0;
}