/*
   Documentation
Name : T.Lakshminarayana
Date :05/03/2024
Title :To remove duplicate elements in a given array
Sample input :Enter the size: 5

              Enter elements into the array: 5 1 3 1 5
Sample output :After removing duplicates: 5 1 3
*/

#include <stdio.h>

void fun(int arr1[], int size, int arr2[], int *new_size)
{
    int i,j,flag;
    *new_size=0;
    for(i=0;i<size;i++)
    {
        flag=0;
        for(j=0;j<i;j++)
        {
            if(arr1[i]==arr1[j])
            {
                flag=1;
                break;
            }
        }
        if(flag==0)
        {
            arr2[*new_size]=arr1[i];
            (*new_size)++;
        }
    }
}


int main()
{
    int size;
    printf("Enter the size:");
    scanf("%d",&size);
    printf("Enter elements into the array:");
    int arr1[size],arr2[size];
    for(int i=0;i<size;i++)
    {
        scanf("%d",&arr1[i]);
    }
    int new_size;
    fun(arr1,size,arr2,&new_size);
    printf("After removing duplicates:");
    for(int i=0;i<new_size;i++)
    {
        printf("%d ",arr2[i]);
    }
    return 0;

}