/*
   Documentation
Name : T.Lakshminarayana
Date :04/03/2024
Title :To implement your own ispunct() function
Sample input :Enter the character: a
Sample output :Entered character is not punctuation character
*/


#include <stdio.h>
#include <ctype.h>

int my_ispunct(int ch)
{
    return ispunct(ch);
}

int main()
{
    char ch;

    printf("Enter the character: ");
    scanf("%c", &ch);

    if (my_ispunct(ch))
    {
        printf("Entered character is punctuation character\n");
    }
    else
    {
        printf("Entered character is not punctuation character\n");
    }

    return 0;
}