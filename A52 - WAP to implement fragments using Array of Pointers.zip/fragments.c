/*
   Documentation
Name : T.Lakshminarayana
Date :11/04/2024
Title : To implement fragments using Array of Pointers
Sample input :Enter no.of rows : 3
              Enter no of columns in row[0] : 4
              Enter no of columns in row[1] : 3
              Enter no of columns in row[2] : 5
              Enter 4 values for row[0] : 1 2 3 4
              Enter 3 values for row[1] : 2 5 9
              Enter 5 values for row[2] : 1 3 2 4 1
Sample output :Before sorting output is:

               1.000000 2.000000 3.000000 4.000000 2.500000

               2.000000 5.000000 9.000000 5.333333

               1.000000 3.000000 2.000000 4.000000 1.000000 2.200000

               After sorting output is:

               1.000000 3.000000 2.000000 4.000000 1.000000 2.200000

               1.000000 2.000000 3.000000 4.000000 2.500000

               2.000000 5.000000 9.000000 5.333333
*/


#include <stdio.h>
#include <stdlib.h>
//protype function float fragments
float fragments(float size, float *arr[], int col[]);

int main()
{
    //initialize int size
    int size;
    //printing the entered rows
    printf("Enter no of rows : ");
    //storing the address of size
    scanf("%d",&size);
    //declare float pointer arr[size]
    float * arr[size];
    //initialize int col[size]
    int col[size];
    //running for loop i<size times
    for(int i = 0; i < size; i++)
    {
        //printing the entered columns as per rows
        printf("Enter no of columns in row[%d] : ",i);
        //storing the address of coloumns of elements
        scanf("%d",&col[i]);
        //allocate the memory using dynamic memory allocation
        arr[i] = malloc((col[i] + 1) * sizeof(float));
    }
    //calling the function
    fragments(size, arr, col);
}
//defining the function float fragments
float fragments(float size, float *arr[],int col[])
{
    //initialize int i,j
    int i, j;
    //running for loop for i<size times
    for(i = 0; i < size; i++)
    {
        //printing the entered no of coloumns as per rows
        printf("Enter %d values for row[%d]: ",col[i],i);
        //running for loop for j<col[i] times
        for(j = 0; j < col[i]; j++)
        {
            //storing the address array of rows and coloumns
            scanf("%f",&arr[i][j]);
        }
    }
    //printing the output before sorting
    printf("Before sorting output is:\n");
    //running for loop for i<size times
    for(i = 0;i < size; i++)
    {
        //declare float res=0
        float res = 0;
        //running for loop for j<col[i] times
        for(j = 0; j < col[i]; j++)
        {
            //printing the rows and coloumns
            printf("%f ",arr[i][j]);
            //storing res=res+arr[i][j]
            res = res + arr[i][j];
        }
        //calculate average
        arr[i][j] = res / j;
        //storing the average
        printf("%f\n",arr[i][j]);
    }
    //printing the output after sorting
    printf("After sorting output is:\n");
    //running for loop
    for(i = 0; i < size; i++)
    {
        //running for loop
        for(j = i + 1; j < size; j++)
        {
            //check the condition if(arr[i][col[i]] is greater than arr[j][col[j]] or not)
            if(arr[i][col[i]] > arr[j][col[j]])
            {
                //storing arr[i] into temp variable
                float *temp = arr[i];
                //storing the arr[i] into arr[j]
                arr[i] = arr[j];
                //storing the temp value into arr[j]
                arr[j] = temp;
                //declare temp1
                int temp1;
                //atoring col[i] into temp1
                temp1 = col[i];
                //storing col[j] into col[i]
                col[i] = col[j];
                //storing temp1 value into col[j]
                col[j] = temp1;
            }
        }
    }
    //running for loop
    for(i = 0; i < size; i++)
    {
        //running for loop
        for(j = 0; j <= col[i]; j++)
        {
            //printing the rows and coloumns
            printf("%f ",arr[i][j]);
        }
        //printing the new line
        printf("\n");
    }
}