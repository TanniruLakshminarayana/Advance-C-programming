/*
   Documentation
Name : T.Lakshminarayana
Date :05/03/2024
Title:To replace each string of one or more blanks by a single blank
      
Sample input :Enter the string with more spaces in between two words
Sample output :Pointers     are               sharp     knives.
               Pointers are sharp knives.
*/


#include<stdio.h>

void replace_blank(char []);

int main()
{
        char str[100];

        //printf("Enter the string with more spaces in between two words\n");
        scanf("%[^\n]", str);
        replace_blank(str);
        printf("%s\n", str);
}
void replace_blank(char *str) 
{
    //initialize variable for loop
    int i, j;
    
    //loop through each character in string
    for (i = 0, j = 0; str[i] != '\0'; i++) 
    {
        // if the current character is not a space, or it's a space but the next character is not a space
        if (str[i] != ' ' || (str[i] == ' ' && str[i + 1] != ' ')) 
        {
            //copy non space charater to new position
            str[j++] = str[i];
        }
    }
    //terminate string at new position
    str[j]='\0';
}