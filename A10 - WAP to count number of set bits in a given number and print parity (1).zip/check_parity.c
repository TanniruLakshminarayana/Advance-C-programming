//
/*
NAME : Lakshminarayana
DATE : 15/02/2024
TITLE : WAP to find which day of the year.
SAMPLE INPUT : Enter the number : 7

Number of set bits = 3

SAMPLE OUTPUT : Bit parity is odd
*/

#include <stdio.h>

// Function to count the number of set bits in a number
int countSetBits(int num) {
    int count = 0;
    
    // Iterate through each bit of the number
    while (num) {
        // Increment the count if the least significant bit is set (1)
        count += num & 1;
        
        // Right shift the number by 1 to check the next bit
        num >>= 1;
    }
    
    return count;
}

int main() {
    int num;

    // Getting the number from the user
    printf("Enter the number: ");
    scanf("%d", &num);

    // Counting the number of set bits
    int set_bits = countSetBits(num);

    // Checking the parity of the number of set bits
    if (set_bits % 2 == 0) {
        // If the count of set bits is even, print "Even"
        printf("Number of set bits = %d\n", set_bits);
        printf("Bit parity is Even\n");
    } else {
        // If the count of set bits is odd, print "Odd"
        printf("Number of set bits = %d\n", set_bits);
        printf("Bit parity is Odd\n");
    }
    return 0;
}