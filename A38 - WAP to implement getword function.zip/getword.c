/*
   Documentation
Name : T.Lakshminarayana
Date :10/04/2024
Title :To implement getword function
Sample input :Enter the string : Welcome to Emertxe
Sample output :You entered Welcome and the length is 7
*/


#include <stdio.h>
#include <string.h>
int getword(char *str)
{
    int length = 0;
    // Skip leading spaces
    while (*str == ' ')
    {
        str++;
    }
    // Count characters until a space or end of string is encountered
    while (*str != ' ' && *str != '\0')
    {
        length++;
        str++;
    }
    return length;
}

int main()
{
    char input[100];
    printf("Enter the string: ");
    fgets(input, sizeof(input), stdin);

    // Remove trailing newline if present
    if (input[strlen(input) - 1] == '\n')
    {
        input[strlen(input) - 1] = '\0';
    }

    int length = getword(input);
    printf("You entered %.*s and the length is %d\n", length, input, length);
    return 0;
}