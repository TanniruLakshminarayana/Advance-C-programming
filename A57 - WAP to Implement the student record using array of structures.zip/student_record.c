/*
   Documentation
Name : T.Lakshminarayana
Date :11/04/2024
Title :To Implement the student record using array of structures
Sample input :
Enter no.of students : 2
Enter no.of subjects : 2
Enter the name of subject 1 : Maths
Enter the name of subject 2 : Science
----------Enter the student datails-------------
Enter the student Roll no. : 1
Enter the student 1 name : Nandhu
Enter Maths mark : 99
Enter Science mark : 91
----------Enter the student datails-------------
Enter the student Roll no. : 2
Enter the student 2 name : Bindhu
Enter Maths mark : 88
Enter Science mark : 78
Sample output :
----Display Menu----
1. All student details
2. Particular student details
Enter your choice : 2

----Menu for Particular student----
1. Name.
2. Roll no.
Enter you choice : 1
Enter the name of the student : Nandhu
Roll No.   Name           Maths         Science       Average       Grade
1              Nandhu        99               91                95                  A
Do you want to continue to display(Y/y) : n
*/

#include <stdio.h>
#include <stdlib.h>
//prototype function my_strcmp
int my_strcmp(char *str1, char *str2);
//prototype function char grade
char grade(float avg);
//creating the structure
struct student          
{
    //initialize int roll_num
	int roll_num;
	//declare char name[50]
	char name[50];
	//initilaize int mark
	int *mark;
};
int main()
{
    //declare char ch1,ch2
	char ch1, ch2;
	//do while
	do
	{
	    //initilaize int no_of_students=0,no_of_subjects=0
		int no_of_students = 0, no_of_subjects = 0;
		//declare character char[30] with type casting
		char (*str)[30];
		//initialize int option,choice
		int option, choice;
		//declare float sum=0,avg=0
		float sum = 0, avg = 0;
		// prompt to read num of students
		printf("Enter number of students : ");
		//storing the input of no_of_students
		scanf("%d", &no_of_students);
		//printing the entered number of subjects
		printf("Enter number of subjects : ");
		//storing the input of no_of_subjects
		scanf("%d", &no_of_subjects);
		// Memory allocation to store subject
		str = malloc (sizeof(*str) * no_of_subjects);
		// structure variable declaration
		struct student S[no_of_students];
		//running for loop for no_of_subjects
		for (int i = 0; i < no_of_subjects; i++)
		{
		    //printing the name of subjects
			printf("Enter name of the Subject %d : ", i + 1 );
			//storing the input of subject name
			scanf("%s", str[i]);
		}
		//running for loop for no_of_students
		for (int i = 0; i < no_of_students; i++)
		{//printing the statement
			printf("-------------------------Enter students details--------------------\n");
			//printing the student roll numbers
			printf("Enter the student %d Roll Number : ", i + 1);
			fflush(stdin);
			//read roll number from user
			scanf("%d", &S[i].roll_num); 
			//enter the student names
			printf("Enter the student %d name : ", i + 1);
			fflush(stdin);
			//read the name from user 
			scanf("%s",S[i].name); 
			// Memory allocation to store mark for each student
			S[i].mark = ( int * )malloc ( sizeof(int) * no_of_subjects);
			//running for loop for no_of_subjects
			for (int j = 0; j < no_of_subjects; j++)
			{
			    //printing the entered number of mark
				printf("Enter the %s mark : ", str[j]);
				//read mark from user
				scanf("%d", &S[i].mark[j]);
			}
		}
		//running do while loop
		 do
		{
		    //printing the statement
			printf("-----------------------DISPLAY MENU-----------------------------\n");
			//printing the statements
			printf("1. All Student Details\n2. Particular Student Details\nEnter your choice : ");
			//read the option
			scanf("%d", &option);
			//running switch case for student details,grade
            switch (option)
			{
				case 1 :
					printf("Menu for All Student Details\n");
					printf("Roll no\t\tName\t\t");
					for(int j = 0; j < no_of_subjects; j++)
					{
						printf("%s\t\t", str[j]);  // printing subjects
					}
					printf("Average\t\tGrade\n");
					for (int i = 0; i < no_of_students; i++)
					{
						sum = 0;
						for (int j = 0; j < no_of_subjects; j++)
						{
							sum = sum + S[i].mark[j];   // adding mark for each student
						}
						printf("%d\t\t%s\t\t", S[i].roll_num, S[i].name);   // display roll num and name

						for (int j = 0; j < no_of_subjects; j++)
						{
							printf("%d\t\t", S[i].mark[j]);   // display mark of each subject
						}
						avg = sum / no_of_subjects;   // finding avg for each student
						printf("%g\t\t%c\n", avg, grade(avg));  // display avg and grade
					}
					break;
				case 2 :
					{
						printf("-----------------------Menu for particular student--------------------\n");
						printf("1. Name\n2. Roll no\nEnter your choice: ");
						scanf("%d",&choice);
						if (choice == 1)
						{
							char student_name[40];
							// Prompt to read name of the student to display the detail of that particular student
							printf("Enter name of the student : ");
							scanf("%s",student_name);
							sum = 0;
							avg = 0;
							int count = 0;
							for (int i = 0; i < no_of_students; i++)
							{
								if ( my_strcmp (student_name, S[i].name) == 0)   // function call to compare names
                                {
									count++;
									printf("Roll No\t\tName\t\t\t");
									for(int j = 0; j < no_of_subjects; j++)
									{
										printf("%s\t\t", str[j]);
										sum = sum + S[i].mark[j];
									}
									avg = sum / no_of_subjects;
									printf("Average\t\tGrade\n");
									printf("%d\t\t%s\t\t",S[i].roll_num, S[i].name);
									for(int j = 0; j < no_of_subjects; j++)
									{
										printf("%d\t\t",S[i].mark[j]);
									}
									printf("%g\t\t%c\n",avg,grade(avg));
								}
							}
							if (count == 0)
							{
								printf("%s student detail is not available\n", student_name);
							}
						}
						else if ( choice == 2)
						{
							int number;
							sum = 0;
							avg = 0;                                 
							printf("Enter the Student Roll Number : ");
							scanf("%d",&number);
							for (int i=0; i < no_of_students; i++)
							{
								if ( number == S[i].roll_num )  // comparing roll number
								{
									printf("Roll No\t\tName\t\t\t");
									for(int j=0; j < no_of_subjects; j++)
									{
										printf("%s\t\t", str[j]);
										sum = sum + S[i].mark[j];
									}
									avg = (sum / no_of_subjects);
									printf("Average\t\tGrade\n");
									printf("%d\t\t%s\t\t",S[i].roll_num, S[i].name);
									for(int j=0; j < no_of_subjects; j++)
                                    {
										printf("%d\t\t",S[i].mark[j] );
									}
									printf("%g\t\t%c\n",avg,grade(avg));
								}

							}
						}
						else if (choice != 1 && choice != 2)
						{
							printf("Enter valid option\n");
						}
						break;
							}
				default :
						printf("Error : Invalid choice \n");
						break;
			}
			printf("Do you want to continue to display(Y/y) : "); // asks permisssion from user to repeat the operation
			   scanf(" %c",&ch2);
			   }while (ch2 == 'y' || ch2 == 'Y');   
			   // condition checking to repeat the display function
			free(str);
			str = NULL;
			   }while (ch1 == 'y' || ch1 == 'Y');        // condition checking for repetetion of reading student details
			   return 0;
			   
}
char grade(float avg)       //finding grade for marks
{
	if ( avg >= 90 )
	{
		return 'A';
	}
	else if (avg >= 80 && avg < 90)
	{      
		return 'B';
	}
else if (avg >= 70 && avg < 80)
	{
		return 'C';
	}
    else if (avg >= 60 && avg < 70)
	{
		return 'D';
	}
	else if (avg >= 50 && avg < 60)
	{
		return 'E';
	}
	else
	{
		return 'F';
	}
}
int my_strcmp( char *str1, char *str2)
{
	// compare two strings with case insensitive
	while ( (*str1 && *str2) && (*str1 == *str2) || (*str1 - 32 == *str2) || (*str1 == *str2 - 32) )
	{
		str1++;
		str2++;
	}
	return *str2 - *str1;  // If both the strings are same means it will return 0
}