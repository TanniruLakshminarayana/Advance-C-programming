/*
Documentation
Name: T.Lakshminarayana
Date: 01/04/2024
Description: To Provide a menu to manipulate or display the value of variable of type t
Sample input:
                Menu :
                1. Add element
                2. Remove element
                3. Display element
                4. Exit from the program

                Choice ---> 1
                Enter the type you have to insert:
                1. int
                2. char
                3. float
                4. double
                Choice ---> 2
                Enter the char : k
                1. Add element
                2. Remove element
                3. Display element
                4. Exit from the program
                Choice ---> 3
                -------------------------
                0 -> k
                -------------------------
                1. Add element
                2. Remove element
                3. Display element
                4. Exit from the program
                Choice ---> 1
                Enter the type you have to insert:
                1. int
                2. char
                3. float
                4. double
                Choice ---> 1
                Enter the int : 10
                1. Add element
                2. Remove element
                3. Display element
                4. Exit from the program
                Choice ---> 3
                ------------------------
                0 -> k (char)
                1 -> 10 (int)
                ------------------------
                1. Add element
                2. Remove element
                3. Display element
                4. Exit from the program

                Choice ---> 2
                0 -> k
                1 -> 10
                Enter the index value to be deleted : 0
                index 0 successfully deleted.
                1. Add element
                2. Remove element
                3. Display element
                4. Exit from the program
                Choice ---> 4


*/

#include<stdio.h>
#include<stdlib.h>
//function delcaration
short int int_flag, int_flag1, char_flag, short_flag,double_flag;
void Add_element(void *mem);
void remove_element(void *mem);
void display_element(void *mem);
int main()
{
    int option,option1;
    //dynamic memory allocation
    void *mem = calloc(1, sizeof(double));
    printf("Menu :\n");
    while(1)
    {
        printf("1. Add element\n2. Remove element\n3. Display element\n4. Exit from the program\n");    //read choice from user
        printf("Choice ---> ");
        scanf("%d" , &option);
        switch (option)//read option from user
        {
            case 1: Add_element(mem);
            break;
            case 2: remove_element(mem);
                    break;
                    case 3: display_element(mem);
                    break;
                    case 4: exit (0);
                    break;
                    default:printf("Invalid choice : Enter only given choice\n");
        }
    }
    return 0;
}
void Add_element(void *mem)
{
    int option1;
    printf("Enter the type you have to insert:\n");
    printf("1. int\n2. char\n3. short\n4. float\n5. double\n");
    printf("Choice ---> ");
    scanf("%d", &option1);
    switch ( option1)
    {
        case 1:
        {
            if (int_flag == 0 && double_flag == 0)
            {
                printf("Enter the int : ");
                    scanf("%d", ((int *)mem +1));  //genearlly 8 bytes memory in first 4 bytes we are trying to store
                    int_flag = 1;
                    int_flag1 = 1;
                }
                else
                {
                    printf("don't have enough space to store\n");
                }
                break;
        }
        case 2:
        {
            if (char_flag == 0 && double_flag == 0)
            {
                getchar();
                    printf("Enter the char : ");
                    scanf("%c", ((char *)mem +2));//remaining place after int try to store charcter
                    char_flag = 1;
                }
                else
                {
                    printf("don't have enough space to store\n");
                }
                break;
        }
        case 3:
        {
            if (short_flag == 0 && double_flag == 0)
                {
                    printf("Enter the short : ");
                    scanf("%hd", ((short *)mem +0));//remaining place after char trying to store short
                    short_flag = 1;
                }
                else
                {
                    printf("don't have enough space to store\n");
                }
                break;
        }
        case 4:
        {
                if (int_flag == 0 && double_flag == 0)
                {
                    printf("Enter the float : ");
                    scanf("%f", ((float *)mem +1));//remaining place after short to store float
                    int_flag = 1;
                }
                else
                {
                    printf("don't have enough space to store\n");
                }
                break;
            }
        case 5:
        {
            if (double_flag == 0 && int_flag == 0 && char_flag == 0 && short_flag == 0)
            {
                printf("Enter the double : ");
                    scanf("%lf", ((double *)mem +0));//remaining place after float to store double
                    double_flag = 1;
                }
                else
                {
                    printf("don't have enough space to store\n");
                }
                break;
        }
        default :printf("Invalid choice : Enter only given choice\n");
    }
}
void remove_element(void *mem)
{
    int option1;
    display_element(mem);
    //read element to be deleted
    printf("Enter the index value to be deleted : ");
    scanf("%d", &option1);
    switch(option1)
    {
        case 0:
        {

        if(int_flag == 1)
        {
            int_flag = 0;
            int_flag1 = 0;
            printf("index %d successfully deleted.\n",option1);
        }
        else
        printf("There is nothing to be deleted\n");
        break;
        }
        case 1:
        {
            if(char_flag == 1)
            {
                char_flag = 0;
                    printf("index %d successfully deleted.\n",option1);
                }
                else
                    printf("There is nothing to be deleted\n");
                break;
        }
        case 2:
        {
            if(short_flag == 1)
            {
                short_flag = 0;
                printf("index %d successfully deleted.\n",option1);
            }
            else
            printf("There is nothing to be deleted\n");
            break;
        }
        case 3:
        {
            if(int_flag == 1)
            {
                int_flag = 0;
                    printf("index %d successfully deleted.\n",option1);
                }
                else
                    printf("There is nothing to be deleted\n");
                break;
        }
        case 4:
        {
            if(double_flag == 1)
                {
                    int_flag = 0;
                    printf("index %d successfully deleted.\n",option1);
                }
                else
                    printf("There is nothing to be deleted\n");
                break;
        }
        default:
        printf("Invalid choice : Enter only given choice\n");
    }
}
void display_element(void *mem)
{
    //condition to display elements
    if (int_flag || char_flag || short_flag || double_flag)
    {
        printf("------------------------\n");
        if(int_flag && int_flag1)
        printf("0--->%d (int)\n", ((int)mem + 1));
        if(char_flag)
        printf("1--->%c (char)\n", ((char)mem + 2));
        if(short_flag)
            printf("2--->%hd (short)\n", ((short)mem + 0));
            if(int_flag && int_flag1 == 0)
            printf("3--->%g (float)\n", ((float)mem + 1));
            if(double_flag)
            printf("4--->%g (int)\n", ((double)mem + 0));
            printf("------------------------\n");
    }
    else
        printf("Memory is empty it contains nothing to print\n");
}