/*
   Documentation
Name : T.Lakshminarayana
Date :11/04/2024
Title :To define a macro swap (t, x, y) that swaps 2 arguments of type t
Sample input :1. Int
              2. char
              3. short
              4. float
              5. double
              6. string
Sample output :Enter you choice : 1

               Enter the num1 : 10
               Enter the num2 : 20
               After Swapping :
               num1 : 20
               num2 : 10
*/

#include <stdio.h>

// Define macro swap(t, x, y)
#define swap(t, x, y) { t temp = x; x = y; y = temp; }

int main() {
    int choice;
    printf("1. Int\n2. char\n3. short\n4. float\n5. double\n6. string\nEnter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1: {
            int num1, num2;
            printf("Enter the num1: ");
            scanf("%d", &num1);
            printf("Enter the num2: ");
            scanf("%d", &num2);
            swap(int, num1, num2);
            printf("After Swapping:\nnum1: %d\nnum2: %d\n", num1, num2);
            break;
        }
        case 2: {
            char char1, char2;
            printf("Enter the char1: ");
            scanf(" %c", &char1);
            printf("Enter the char2: ");
            scanf(" %c", &char2);
            swap(char, char1, char2);
            printf("After Swapping:\nchar1: %c\nchar2: %c\n", char1, char2);
            break;
        }
        case 3: {
            short short1, short2;
            printf("Enter the short1: ");
            scanf("%hd", &short1);
            printf("Enter the short2: ");
            scanf("%hd", &short2);
            swap(short, short1, short2);
            printf("After Swapping:\nshort1: %hd\nshort2: %hd\n", short1, short2);
            break;
        }
        case 4: {
            float float1, float2;
            printf("Enter the float1: ");
            scanf("%f", &float1);
            printf("Enter the float2: ");
            scanf("%f", &float2);
            swap(float, float1, float2);
            printf("After Swapping:\nfloat1: %f\nfloat2: %f\n", float1, float2);
            break;
        }
        case 5: {
            double double1, double2;
            printf("Enter the double1: ");
            scanf("%lf", &double1);
            printf("Enter the double2: ");
            scanf("%lf", &double2);
            swap(double, double1, double2);
            printf("After Swapping:\ndouble1: %lf\ndouble2: %lf\n", double1, double2);
            break;
        }
        case 6: {
            printf("This program does not support swapping strings.\n");
            break;
        }
        default:
            printf("Invalid choice.\n");
    }

    return 0;
}