/*
   Documentation
Name : T.Lakshminarayana
Date :06/03/2024
Title :To generate fibbonacci numbers using recursion
Sample input :Enter a number: 8

Sample output :0, 1, 1, 2, 3, 5, 8
*/

#include <stdio.h>
//Function to calculate fibonacci series using recursion
void positive_fibonacci(int limit, int first, int second, int next)
{
    printf("%d, ",next);
    first=second;
    second=next;
    next=first+second;
    if(next<=limit)
    {
       positive_fibonacci(limit , first, second,next);
    }
}



int main()
{
    int limit;
    //Input from the user
    printf("Enter the limit : ");
    scanf("%d", &limit);
    //Check for invalid input
    if (limit<0)
    {
        printf("Invalid input\n");
        //return error code
        return 1;
    }
    //Function calling
    positive_fibonacci(limit, 0, 1, 0);
}