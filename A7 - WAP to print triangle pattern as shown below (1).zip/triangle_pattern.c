/*
   Documentation
Name : T.Lakshminarayana
Date :01/02/2024
Title :To print triangle pattern as shown below
Sample input :Enter the number: 4
Sample output :
1 2 3 4
5     6
7 8
9
*/

#include<stdio.h>
int main() 
{
    int n;
    int count=1;
    
    // Read the number from the user
    printf("Enter the number: ");
    scanf("%d", &n);

    for (int i = n; i > 0; i--) 
    {
        for (int j = 1; j <= i; j++) 
        {
            if(i == n || j == 1 || i == j)
            {
               printf("%d ", count);
               count++;
            }
            else
            {
                printf("  ");// Print two spaces for each empty spot
            }
        }
        printf("\n");
    }
   return 0;
}
