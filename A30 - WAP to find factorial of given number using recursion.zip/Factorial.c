/*
   Documentation
Name : T.Lakshminarayana
Date :05/03/2024
Title :To find factorial of given number using recursion
Sample input :Enter the value of N : 7

Sample output :Factorial of the given number is 5040
*/

#include <stdio.h>
int factorial(int num)
{
    if(num==0 || num==1)
    {
        return 1;
    }
    else
    {
        return num*factorial(num-1);
    }
}

int main()
{
    static int num;
    scanf("%d",&num);

    static unsigned long long int fact = 1;
    if (num<0)
    {
        printf("Invalid Input\n");
    }
    else
    {
        printf("Factorial of the given number is %d\n",factorial(num));
    }
    char choice;
    scanf(" %c",&choice);
    if(choice=='y' || choice=='Y')
    {
        main();
    }
    return 0;
}