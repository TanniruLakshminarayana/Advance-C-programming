/*
   Documentation
Name : T.Lakshminarayana
Date :04/03/2024
Title :To implement Circular left shift
Sample input :Enter num: 12
              Enter n : 3
Sample output :Result in Binary: 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0
*/

#include <stdio.h>

// Function to perform circular left shift
int circular_left_shift(int num, int n) {
    // Calculate the number of bits in an integer
    int num_bits = sizeof(num) * 8;

    // Perform circular left shift n times
    for (int i = 0; i < n; ++i) {
        // Extract the leftmost bit
        int leftmost_bit = (num >> (num_bits - 1)) & 1;

        // Perform left shift by 1
        num = (num << 1) | leftmost_bit;
    }

    return num;
}

int main() {
    int num, n;

    // Input the number and the number of shifts
    printf("Enter num: ");
    scanf("%d", &num);

    printf("Enter n: ");
    scanf("%d", &n);

    // Perform circular left shift
    int result = circular_left_shift(num, n);

    // Display the result in binary
    printf("Result in Binary: ");
    for (int i = sizeof(result) * 8 - 1; i >= 0; --i) {
        printf("%d ", (result >> i) & 1);
    }
    printf("\n");

    return 0;
}
