/*
   Documentation
Name : T.Lakshminarayana
Date :01/02/2024
Title : To generate AP,GP,HP
Sample input : Enter the First Number 'A': 2
               Enter the Common Difference / Ratio 'R': 3
               Enter the number of terms 'N': 5

Sample output :AP = 2, 5, 8, 11, 14
               GP = 2, 6, 18, 54, 162
               HP = 0.500000, 0.200000, 0.125000, 0.090909, 0.071428

*/

#include<stdio.h>
int main()
{
    int A,R,N;
    int temp;
    float n;
    printf("Enter the First Number 'A': ");
    scanf("%d",&A);
    printf("Enter the Common Difference / Ratio 'R': ");
    scanf("%d",&R);
    printf("Enter the number of terms 'N': ");
    scanf("%d",&N);
    temp = A;    //Storing A value
    if(A > 0 && R > 0 && N > 0) //To generate AP series
    {
        printf("AP = ");
        for(int i=0;i<N;i++)
        {
            printf("%d",A);
            A += R;
            printf(", ");
        }
        printf("\n");
        A=temp;
        printf("GP = ");
        for(int j=0;j<N;j++)  // To generate GP series
        {
            printf("%d",A);
            A *= R;
            printf(", ");
        }
        printf("\n");
        A=temp;
        printf("HP = ");
        for(int k=0;k<N;k++)  // To generate HP series
        {
            n=1/(float)A;
            printf("%f",n);
            A += R;
            printf(", ");
        }
    }
    else
    {
        printf("Invalid input");
    }
return 0;
}