/*
   Documentation
Name : T.Lakshminarayana
Date :10/04/2024
Title : Squeeze the character in s1 that matches any character in the string s2
Sample input :Enter s1 : Dennis Ritchie
              Enter s2 : Linux
Sample output :After squeeze s1 : Des Rtche
*/

#include <stdio.h>

void squeeze(char [], char []);

int main()
{
    char str1[30], str2[30];

    //printf("Enter string1:");
    scanf("%[^\n]", str1);


    //printf("Enter string2:");
    scanf(" %[^\n]", str2);

    squeeze(str1, str2);

    printf("After squeeze s1 : %s\n", str1);

}
void squeeze(char *str1, char *str2){
        int j = 0, i;
        for (j; str1[j] != '\0'; j++){
            for(i = 0; str1[j] != str2[i]; i++){
                if(str2[i] == '\0')
                    break;
            }
            if( str1[j] == str2[i]){
                int k = j;
                j--;
                while ( str1[k] != '\0') {
                    str1[k] = str1[k+1];
                    k++;
                }
            }
        }
}
