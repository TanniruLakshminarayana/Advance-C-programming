/*
   Documentation
Name : T.Lakshminarayana
Date :15/02/2024
Title : To check N th bit is set or not, If yes, clear the M th bit
Sample input :
               Enter the number: 19

               Enter 'N': 1

               Enter 'M': 4
Sample output :
               Updated value of num is 3
*/

#include <stdio.h>

int main()
{
    unsigned int num, n, m;

    // Read the number, N, and M from the user
    printf("Enter the number: ");
    scanf("%u", &num);
    printf("Enter 'N': ");
    scanf("%u", &n);
    printf("Enter 'M': ");
    scanf("%u", &m);

    // Check if Nth bit is set
    if (num & (1 << n))
    {
        // Clear Mth bit
        num &= ~(1 << m);
    }

    // Print the updated value of num
    printf("Updated value of num is %u\n", num);

   return 0;
}
