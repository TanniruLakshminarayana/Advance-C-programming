/*
   Documentation
Name : T.Lakshminarayana
Date :04/03/2024
Title :To find 3rd largest element in an array
Sample input :Enter the size of the Array : 5
              Enter the elements into the array: 5 1 4 2 8
Sample output :Third largest element of the array is 4
*/


#include <stdio.h>

int third_largest(int arr[], int size)
{
    int first,second,third,MIN;
    first=second=third=MIN;
    for(int i=0; i<size; i++)
    {
        if(arr[i]>first)
        {
            third=second;
            second=first;
            first=arr[i];
        }
        else if(arr[i]>second && arr[i]<first)
        {
            third=second;
            second=arr[i];
        }
        else if (arr[i]>third && arr[i]<second)
        {
            third=arr[i];
        }
    }
    return third;
}

int main()
{
    int size, ret;

    //Read size from the user
    printf("Enter the size of the array :");
    scanf("%d", &size);

    int arr[size];

    //Read elements into the array
    printf("Enter the elements into the array:");
    for(int i=0;i<size;i++)
    {
        scanf("%d",&arr[i]);
    }
    //funtion call
    ret = third_largest(arr, size);

    printf("Third largest element of the array is %d\n", ret);
    return 0;
}