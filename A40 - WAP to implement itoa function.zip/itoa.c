/*
   Documentation
Name : T.Lakshminarayana
Date :10/04/2024
Title :To implement itoa function
Sample input :Enter the number : 1234
Sample output :Integer to string is 1234
*/

#include <stdio.h>

void itoa(int num, char str[]);  //function declaration

int main()
{
    int num;
    char str[20] = {'0','\0'};
    
    printf("Enter the number:");
    
    if(scanf("%d",&num) != 0)
    {
        itoa(num, str);      //calling function 
    }
    printf("Integer to string is %s", str);
    return 0;
}
void itoa(int num, char str[])  //function definition
{
    int ind = 0;
    int rev = 0;
    int rem =0;
    if(num < 0) 
    {
        str[0] = '-';
        num = -1 * num;
        ind = 1;
    }
    
    while(num)   //reversing number
    {
        rem =num % 10;
        rev = rev*10 + rem;
        num = num / 10;
    }

    int i;
    for(i = ind; rev != 0;i++)
    {
        str[i] = (rev % 10) + '0';   //converting integer to char and storing in string
        rev = rev / 10;
    }
     str[i]='\0';
}
