/*
   Documentation
Name : T.Lakshminarayana
Date :28/02/2024
Title :To replace 'n' bits of a given number
Sample input :Enter the number: 10

              Enter number of bits: 3

              Enter the value: 12
Sample output :Result = 12
*/

#include <stdio.h>
// Function to replace 'n' bits of a given number
int replace_nbits(int num, int n, int val)
{
    // Create a mask with 'n' bits set to 1
    int mask=(1<<n)-1;
    // Clear the last 'n' bits of num
    num = num & (~mask);
    int bits= val & mask;
    // Replace the last 'n' bits of num with bits from val
    num = num | bits;
     return num;
}

int main()
{
    // Input from the user
    int num, n, val, res = 0;

    scanf("%d%d%d", &num, &n, &val);
     // Call the function to replace bits

    res = replace_nbits(num, n, val);

    printf("Result = %d\n", res);
    return 0;
}