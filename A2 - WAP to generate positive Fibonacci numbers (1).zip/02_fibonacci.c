/*
   Documentation
Name : T.Lakshminarayana
Date :01/02/2024
Title :To generate positive Fibonacci numbers
Sample input :Enter a number: 8
Sample output :0 1 1 2 3 5 8
*/

#include<stdio.h>

int main()
{
    int first=0,second=1,next=0,n;
    //Enter user input
    printf("Enter the number:");
    scanf("%d",&n);
    //condition for positive fibonacci series
    if(n>=0)
    {
        while(next<=n)
        {
            printf("%d, ", next);
            //swaping for positive series
        first=second;
        second=next;
        next=first+second;
    }
    }
    else
    {
        //printing invalid input
    printf("invalid input:");
    }
//exit successfully
    return 0;
}

