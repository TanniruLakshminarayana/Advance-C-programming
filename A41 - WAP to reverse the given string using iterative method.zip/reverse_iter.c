/*
   Documentation
Name : T.Lakshminarayana
Date :10/04/2024
Title :To reverse the given string using iterative method
Sample input :Enter a string : Hello World
Sample output :Reverse string is : dlroW olleH
*/

#include <stdio.h>
#include <string.h>

void reverse_iterative(char str[])
{
    int length = strlen(str);
    char temp;
    for (int i = 0; i < length / 2; i++)
    {
        temp = str[i];
        str[i] = str[length - i - 1];
        str[length - i - 1] = temp;
    }
}

int main() {
    char str[100];
    fgets(str, sizeof(str), stdin);

    // Removing the trailing newline character
    if (str[strlen(str) - 1] == '\n')
        str[strlen(str) - 1] = '\0';

    reverse_iterative(str);

    printf("Reversed string is: %s\n", str);

    return 0;
}