/*
   Documentation
Name : T.Lakshminarayana
Date :01/02/2024
Title :To check whether a given number is prime or not.
Sample input :Enter a number: 2
Sample output :2 is a prime number
*/

#include <stdio.h>

// Function to check if a number is prime
int is_prime(int num) {
    int i;

    // Handling special cases:
    // Prime numbers are greater than 1
    if (num <= 1) {
        return 0; // Not a prime
    }

    // Check divisibility by numbers from 2 to square root of num
    // If a number is divisible by any number in this range, it's not prime
    for (i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            return 0; // Not a prime
        }
    }

    return 1; // Prime
}

int main() {
    int num;

    
    scanf("%d", &num);

    // Handling negative input:
    // Negative numbers are not considered prime
    if (num < 0) {
        printf("Invalid input\n");
    } else {
        // Call is_prime function to check if the number is prime
        if (is_prime(num)) {
            printf("%d is a prime number\n", num);
        } else {
            printf("%d is not a prime number\n", num);
        }
    }
    return 0;
}