/*
   Documentation
Name : T.Lakshminarayana
Date :10/04/2024
Title :To check given string is Pangram or not
Sample input :Enter the string: The quick brown fox jumps over the lazy dog
Sample output :The Entered String is a Pangram String
*/


#include <stdio.h>

int pangram(char []);

int main()
{
        char str[100];
        scanf("%[^\n]", str);
    int ret = pangram(str);
        if(ret == 1){
                printf("The Entered String is a Pangram String");
        }
        else
                printf("The Entered String is not a Pangram String");
}

int pangram(char *ind){
        char str1[26]={0};
        for(int i = 0; ind[i] != '\0'; i++){
                if((int)ind[i] >= 65 && (int)ind[i] <= 90){
                        int a = (int)ind[i] - 65;
                        str1[a] = '1';
                }
                if((int)ind[i] >= 97 && (int)ind[i] <= 122){
                        int a = (int)ind[i] - 97;
                        str1[a] = '1';
                }
        }

        int count = 0;
        for(int j = 0; j <= 26; j++){
                if(str1[j] == '1'){
                        count++;
                }
        }
        if(count == 26){
                return 1;
        }
        else
                return 0;
}