//
/*
NAME : T.Lakshminarayana
DATE : 15/02/2024
TITLE : WAP to find which day of the year.
SAMPLE INPUT : Enter the value of 'n' : 20

SAMPLE OUTPUT : The primes less than or equal to 20 are : 2, 3, 5, 7, 11, 13, 17, 19  
*/

#include <stdio.h>
#include <stdbool.h>

// Function to implement Sieve of Eratosthenes algorithm
void sieveOfEratosthenes(int n) {
    // Check for invalid input
    if (n <= 1) {
        printf("Please enter a positive number which is > 1.\n");
        return;
    }

    // Create a boolean array "prime[0..n]" and initialize
    // all entries as true. A value in prime[i] will
    // finally be false if i is not a prime, else true.
    bool prime[n + 1];
    for (int i = 0; i <= n; ++i) {
        prime[i] = true;
    }

    // Start with the first prime number, 2
    for (int p = 2; p * p <= n; ++p) {
        // If prime[p] is not changed, then it is a prime
        if (prime[p] == true) {
            // Update all multiples of p
            // Starting from p*p because multiples of p less than p*p
            // have already been marked.
            for (int i = p * p; i <= n; i += p) {
                prime[i] = false;
            }
        }
    }

    // Print all prime numbers
    printf("The primes less than or equal to %d are: ", n);
    for (int p = 2; p <= n; ++p) {
        if (prime[p]) {
            printf("%d ", p);
        }
    }
    printf("\n");
}

int main() {
    int n;
    printf("Enter the value of 'n': ");
    scanf("%d", &n);
    sieveOfEratosthenes(n);
  return 0;
}