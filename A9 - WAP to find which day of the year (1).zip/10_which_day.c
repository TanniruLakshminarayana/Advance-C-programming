/*
   Documentation
Name : T.Lakshminarayana
Date :08/02/2024
Title :WAP to find which day of the year
Sample input :
Sample output :Enter the value of 'n' : 9
Choose First Day :
1. Sunday
2. Monday
3. Tuesday
4. Wednesday
5. Thursday
6. Friday
7. Saturday
Enter the option to set the first day : 2
The day is Tuesday
*/

#include <stdio.h>

int main() {
    int n, start_day;

    // Input the value of 'n'
    printf("Enter the value of 'n' (1 <= n <= 365): ");
    scanf("%d", &n);

    // Input for choosing the first day
    printf("\nChoose First Day:\n");
    printf("1. Sunday\n2. Monday\n3. Tuesday\n4. Wednesday\n5. Thursday\n6. Friday\n7. Saturday\n");
    printf("Enter the option to set the first day: ");
    scanf("%d", &start_day);

    // Validate input for start_day
    if (start_day < 1 || start_day > 7) {
        printf("Error: Invalid input, first day should be > 0 and <= 7\n");
        return 1;  // Exit with error code
    }

    // Validate input for 'n'
    if (n < 1 || n > 365) {
        printf("Error: Invalid Input, n value should be > 0 and <= 365\n");
        return 1;  // Exit with error code
    }

    // Calculate the day of the week for the nth day
    int day = (start_day - 1 + ((n - 1) % 7)) % 7;

    // Output the result
    printf("The day is ");
    switch (day) {
        case 0:
            printf("Sunday");
            break;
        case 1:
            printf("Monday");
            break;
        case 2:
            printf("Tuesday");
            break;
        case 3:
            printf("Wednesday");
            break;
        case 4:
            printf("Thursday");
            break;
        case 5:
            printf("Friday");
            break;
        case 6:
            printf("Saturday");
            break;
    }

    printf("\n");

    return 0;  // Exit successfully
}
