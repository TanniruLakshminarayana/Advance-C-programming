/*
   Documentation
Name : T.Lakshminarayana
Date :01/03/2024
Title :To toggle 'n' bits from given position of a number
Sample input :Enter the number: 10

              Enter number of bits: 3

              Enter the pos: 5
Sample output :
              Result = 50
*/

#include <stdio.h>
//function defination
int toggle_nbits_from_pos(int num , int n , int pos)
{
    //toggle n bits from given position of a number
    return (num^(((1<<n)-1)<<((pos-n)+1)));
}

int main()
{
    //Enter the user inputs
    int num, n, pos, res = 0;

    printf("Enter num, n and val:");
    scanf("%d%d%d", &num, &n, &pos);
    //calling function
    res = toggle_nbits_from_pos(num, n, pos);
    //printing the toggle bits
    printf("Result = %d\n", res);
}