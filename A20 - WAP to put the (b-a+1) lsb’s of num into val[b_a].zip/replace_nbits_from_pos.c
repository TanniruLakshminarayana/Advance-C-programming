/*
   Documentation
Name : T.Lakshminarayana
Date :01/03/2024
Title :To put the (b-a+1) lsb’s of num into val[b:a]
Sample input :
               Enter the value of 'num' : 11
               Enter the value of 'a' : 3
               Enter the value of 'b' : 5
               Enter the value of 'val': 174
Sample output :
               Resuilt : 158
*/

#include <stdio.h>
//function definition
int replace_nbits_from_pos(int num, int a, int b, int val)
{
    return (((((1<<(b-a+1))-1)&num)<<a)|((~(((1<<(b-a+1))-1)<<a))&val));
}

int main()
{
    int num, a, b, val, res = 0;
    //Enter the user inputs
    //validating the input
    printf("Enter num, a, b, and val:");
    scanf("%d%d%d%d", &num, &a, &b, &val);

    if((b>0&&b<=31)&&(a>=0&&a<=b))
    {
     // calling the replace_bits_from _pos function
    res = replace_nbits_from_pos(num, a, b, val);
    }

    printf("Result = %d\n", res);
    return 0;
}