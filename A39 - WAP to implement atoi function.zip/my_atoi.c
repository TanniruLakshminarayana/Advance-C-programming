/*
   Documentation
Name : T.Lakshminarayana
Date :10/04/2024
Title :To implement atoi function
Sample input :Enter a numeric string: 12345
Sample output :String to integer is 12345
*/

#include <stdio.h>
#include <string.h>
int my_atoi(const char *s)
{
    int result = 0;
    int sign = 1;
    while (*s == ' ')
    {
        s++;
    }
    if (*s == '-')
    {
        sign = -1;
        s++;
    } else if (*s == '+')
    {
        s++;
    }
    while (*s >= '0' && *s <= '9')
    {
        result = result * 10 + (*s - '0');
        s++;
    }

    return sign * result;
}

int main() 
{
    char str[100];
    printf("Enter a numeric string: ");
    fgets(str, sizeof(str), stdin);
    if (str[strlen(str) - 1] == '\n')
    {
        str[strlen(str) - 1] = '\0';
    }
    int number = my_atoi(str);
    printf("String to integer is %d\n", number);
    return 0;
}