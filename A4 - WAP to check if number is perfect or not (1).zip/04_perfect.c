/*
   Documentation
Name : T.Lakshminarayana
Date :05/02/2024
Title :WAP to check if number is perfect or not
Sample input :Enter a number: 6
Sample output :Yes, entered number is perfect number
*/

#include<stdio.h>

int main()
{
    //Declare variables
    int num,sum=0,i,rem;
    //prompt user for input
    printf("Enter the number:");
    scanf("%d",&num);
    if(num>0)
    {
    // Check for proper positive divisors and calculate sum
    for (i=1; i<num; i++ )
    {
       rem=num%i;
       if (rem == 0)
        {
            sum=sum+i;
        }
    }
    //Check if the number is perfect or not and display the result
    if(sum==num)
        printf("Yes, entered number is perfect number\n");
    else
        //Display number is not perfect number
        printf("No, entered number is not a perfect number\n");
    }
    else
    {
        printf("Error : Invalid Input, Enter only positive number");
    }
    return 0;
}
