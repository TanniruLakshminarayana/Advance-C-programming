/*
   Documentation
Name : T.Lakshminarayana
Date :29/02/2024
Title :To get 'n' bits from given position of a number
Sample input :Enter the number: 12

              Enter number of bits: 3

              Enter the pos: 4
Sample output :
              Result = 3
*/

#include <stdio.h>
//Function to get 'n' bits from a given position of a number
int get_nbits_from_pos(int num, int n, int pos)
{
    //Shift the number 'pos' bits to the right
    //Clear the left bits
    //Return the result
    return (num>>(pos-n+1))&~(~0<<n);
}

int main()
{
    //Read the values of num n pos from user
    int num, n, pos, res = 0;

    printf("Enter num, n and val:");
    scanf("%d%d%d", &num, &n, &pos);
    // Fetch n number of bits from given position 'pos'
    res = get_nbits_from_pos(num, n, pos);
    //Print the decimal value
    printf("Result = %d\n", res);
}
