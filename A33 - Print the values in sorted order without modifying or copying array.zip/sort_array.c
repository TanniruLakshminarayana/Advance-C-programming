/*
   Documentation
Name : T.Lakshminarayana
Date :06/03/2024
Title :print the values in sorted order without modifying or copying array
Sample input :Enter the size : 5
              Enter 5 elements 
              10 1 3  8 -1
Sample output :After sorting: -1 1 3 8 10
               Original array values 10 1 3 8 -1

*/


#include <stdio.h>

void print_sort(int [], int);

int main()
{
    int size, iter;

    scanf("%d", &size);

    int arr[size];

    for (iter = 0; iter < size; iter++)
    {
        scanf("%d", &arr[iter]);
    }
    //calling sort print functin
    print_sort(arr, size);

        printf("Original array values "); //prints original array values
        for (iter = 0; iter < size; iter++){
                printf("%d ", arr[iter]);
        }
}

void print_sort(int *arr, int size){
        int small = arr[0], large = arr[1], n = size - 1;

        for(int i = 0; i < size; i++){ //to find small and largest of given array
                if( small > arr[i] ){
                        small = arr[i];
                }
                if( large < arr[i] ){
                        large = arr[i];
                }
        }
        printf("After sorting: %d ", small);

        int next_small = large;
        while ( n ){ //runs until size-1 times

                for (int i = 0; i < size; i++){ //runs size times to find next small
                        if(arr[i] > small && arr[i] < next_small){
                                next_small = arr[i];
                        }
                }
                printf("%d ", next_small);
                small = next_small; //swapping small with next samll, in order to find remaining next smalls
                next_small = large; // default large is initialised in next small for comparing
                n--; //while loop decremented after every find
        }
       printf("\n");
}