/*
   Documentation
Name : T.Lakshminarayana
Date :11/04/2024
Title :Variance calculation with dynamic arrays
Sample input :Enter the no.of elements : 10

              Enter the 10 elements:
              [0] -> 9
              [1] -> 12
              [2] -> 15
              [3] -> 18
              [4] -> 20
              [5] -> 22
              [6] -> 23
              [7] -> 24
              [8] -> 26
              [9] -> 31
Sample output :Variance is 40.000000
*/


#include <stdio.h>
#include <stdlib.h>

// Function to calculate the mean of an array
float calculateMean(int *arr, int size) {
    float sum = 0;
    for (int i = 0; i < size; i++) {
        sum += arr[i];
    }
    return sum / size;
}

// Function to calculate the variance of an array
float calculateVariance(int *arr, int size, float mean) {
    float sumOfSquaredDifferences = 0;
    for (int i = 0; i < size; i++) {
        float diff = arr[i] - mean;
        sumOfSquaredDifferences += diff * diff;
    }
    return sumOfSquaredDifferences / size;
}

int main() {
    int size;

    // Input the number of elements
    printf("Enter the number of elements: ");
    scanf("%d", &size);

    // Dynamically allocate memory for the array
    int *arr = (int *)malloc(size * sizeof(int));
    if (arr == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Input the elements of the array
    printf("Enter the %d elements:\n", size);
    for (int i = 0; i < size; i++) {
        printf("[%d] -> ", i);
        scanf("%d", &arr[i]);
    }

    // Calculate the mean of the array
    float mean = calculateMean(arr, size);

    // Calculate the variance of the array
    float variance = calculateVariance(arr, size, mean);

    // Output the result
    printf("Variance is %.6f\n", variance);

    // Free dynamically allocated memory
    free(arr);

    return 0;
}