/*
   Documentation
Name : T.Lakshminarayana
Date :11/04/2024
Title :To define a macro SIZEOF(x), without using sizeof operator
Sample input :size of data types
Sample output :Size of int : 4 bytes
               Size of char : 1 byte
               Size of float : 4 bytes
               Size of double : 8 bytes
               Size of unsigned int : 4 bytes
               Size of long int : 8 bytes
*/


#include <stdio.h>

// Define macro SIZEOF(x)
#define SIZEOF(x) ((char *)(&x + 1) - (char *)(&x))

int main() {
    int i;
    char c;
    float f;
    double d;
    unsigned int ui;
    long int li;

    // Print the sizes using the SIZEOF macro
    printf("Size of int : %ld bytes\n", SIZEOF(i));
    printf("Size of char : %ld byte\n", SIZEOF(c));
    printf("Size of float : %ld bytes\n", SIZEOF(f));
    printf("Size of double : %ld bytes\n", SIZEOF(d));
    printf("Size of unsigned int : %ld bytes\n", SIZEOF(ui));
    printf("Size of long int : %ld bytes\n", SIZEOF(li));

    return 0;
}