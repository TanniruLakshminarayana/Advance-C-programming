/*
   Documentation
Name : T.Lakshminarayana
Date :06/03/2024
Title :To check whether a given number is prime or not using function.
Sample input :Enter a number: 2


Sample output :2 is a prime number
*/


#include <stdio.h>

int is_prime(int num)
{
    for(int i=2;i<=num/2;i++)
    {
        if(num%i==0)
        {
            return 0;
        }
    }
    return 1;
}




int main()
{
    int num;
    scanf("%d",&num);
    if (num<=0)
    {
        printf("Invalid input\n");
    }
    else
    {
        if(is_prime(num))
        {
            printf("%d is a prime number\n",num);
        }
        else
        {
            printf("%d is not a prime number\n",num);
        }
    }
    return 0;
}