/*
   Documentation
Name : T.Lakshminarayana
Date :01/03/2024
Title :To print 'n' bits from LSB of a number
Sample input :Enter the number: 10

              Enter number of bits: 12
Sample output :
              Binary form of 10: 0 0 0 0 0 0 0 0 1 0 1 0
*/


#include <stdio.h>

int print_bits(int num,int n)
{
    if (n > sizeof(int) * 8)
    {
 // Error checking: If n is greater than integer size, assign n value as sizeof integer
        printf("Error: Number of bits exceeds integer size.\n");
        n = sizeof(int) * 8;
    }
    // Print the binary representation of the last n bits

    for (int i = n-1; i >= 0; i--)
    {
        int bit = (num >> i) & 1;
        printf("%d ", bit);
    }
}

int main()
{
    //Read num and n values from the user
    int num, n;

    printf("Enter num, n :\n");
    scanf("%d%d", &num, &n);
    // Print the binary form of the number
    printf("Binary form of %d:", num);
    print_bits(num, n);
    return 0;
 }