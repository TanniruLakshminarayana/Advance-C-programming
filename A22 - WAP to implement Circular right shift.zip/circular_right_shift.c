/*
   Documentation
Name : T.Lakshminarayana
Date :04/03/2024
Title :To implement Circular right shift
Sample input :Enter num: 12
              Enter n : 3
Sample output :Result : 10000000 00000000 00000000 00000001
*/

#include <stdio.h>

// Function to perform circular right shift
int circular_right(int num, int n) 
{
    // Calculate the number of bits in an integer
   return ((unsigned int)num>>n) | ((unsigned int)num<<(32-n));
}
int print_bits(int ret)
{
    // Display the result in binary
    printf("Result in Binary : ");
    for (int i = 31; i >= 0; i--)
    {
        printf("%d ", (ret>> i) & 1);
    }
}

int main() 
{
    int num, n,ret;

    // Input the number and the number of shifts
    scanf("%d", &num);
    scanf("%d", &n);

    // Perform circular right shift
     ret = circular_right(num, n);
     //calling function

     print_bits(ret);


    return 0;
}