/*
   Documentation
Name : T.Lakshminarayana
Date :11/04/2024
Title :To find the product of given matrix.
Sample input :Enter number of rows : 3
              Enter number of columns : 3
              Enter values for 3 x 3 matrix :
              1      2      3
              1      2      3
              1      2      3
              Enter number of rows : 3
              Enter number of columns : 3
              Enter values for 3 x 3 matrix :

              1      1     1
              2      2     2
              3      3     3
Sample output :Product of two matrix :
               14      14      14
               14      14      14
               14      14      14
*/



#include <stdio.h>
#include <stdlib.h>
//prototype function int matrix_mul
int matrix_mul(int **, int, int, int **, int, int, int **, int, int);

int main()
{
    //initialize int 2d matrix a,int 2d matrix b and result
    int **mat_a, **mat_b, **result;
    //initialize row1
    int row1;
    //initialize int col1
    int col1;
    //printing the entered row
    //printf("Enter the row:\n");
    //storing the address of row1 elements
    scanf("%d",&row1);
    //printing the entered col1
    //printf("Enter the col\n");
    //storing the address of col1 elements
    scanf(" %d",&col1);
    //printing the entered elements
   // printf("Enter the elements  of matrix1");

    //dynamic allocation 
    mat_a =  malloc(row1 * sizeof(int*));
    //running for loop
    for (int i = 0; i < row1; i++)
    {
        //dynamic memory allocation
        mat_a[i] = malloc(col1 * sizeof(int));
    }
     
     //running for loop for first array
    for (int i = 0; i < row1; i++)
    {
        //running for loop for first array
        for (int j = 0; j < col1; j++)
        {
            //storing the address of matrix of row and coloumn
            scanf(" %d",&mat_a[i][j]);
        }
        
    } 
    //initialize int row2
 int row2;
 //initilaize col2
    int col2;
    //printing the entered row
   // printf("Enter the row:\n");
   //storing the address of row2
    scanf("%d",&row2);
    //printing the entered col
    //printf("Enter the col\n");
    //storing the address of col2
    scanf(" %d",&col2);
    //printing the entered elements
    //printf("Enter the elements");

    //dynamic allocation 
    mat_b =  malloc(row2 * sizeof(int *));
    //running for loop
    for (int i = 0; i < row2; i++)
    {
        //dynamic memory allocation
        mat_b[i] = malloc(col2 * sizeof(int));
    }
    //input for second array
    for (int i = 0; i < row2; i++)
    {
        //running for loop for second array
        for (int j = 0; j < col2; j++)
        {
            //storing the adress of matrix of row and coloumn
            scanf(" %d",&mat_b[i][j]);
        }
    }
    //check for impossible matrix demension 
    if(row1 != col2 || row2 != col1)
    {
        //printing the statement
        printf("Matrix multiplication is not possible");
        return 0;
    }
    //dynamic memory allocation
  result =  malloc(row1 * sizeof(int *));
  //runninng for loop
    for (int i = 0; i < row1; i++)
    {
        //dynamic memory allocation
        result[i] = malloc(col2 * sizeof(int));
    }
    //calling the function
    matrix_mul(mat_a, row1, col1, mat_b, row2, col2, result, row1, col2);
    //printing the statement
    printf("Product of two matrix :\n");
    //running for loop
    for (int i = 0; i < row1; i++)
    {
        //running for loop
        for (int j = 0; j < col2; j++)
        {
            //printing the matrix
            printf("%d ",result[i][j]);
        }
        //printing the new line
        printf("\n");
    }
}
//function definition
int matrix_mul(int **mat_a, int row1, int col1, int **mat_b, int row2, int col2, int **result, int row, int col)
{
    //initialize sum=0
    int sum = 0;
    //running for loop
    for (int i = 0; i < row1; i++)
    {
        //running for loop
        for (int j = 0; j < col1; j++)
        {
            //assign sum=0
            sum = 0;
            //running for loop
            for (int k = 0;k < row2; k++)
            {
                //multiply the two matrices and store into sum
                sum += (mat_a[i][k] * mat_b[k][j]);
            }
            //store the result in sum
           result[i][j] = sum;
            
        }
    }
}