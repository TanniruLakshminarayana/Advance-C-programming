/*
   Documentation
Name : T.Lakshminarayana
Date :04/03/2024
Title :To implement your own islower() function
Sample input :Enter the character: a
Sample output :Entered character is lower case alphabet
*/

#include <stdio.h>
#include <ctype.h>
int my_isalnum(int ch)
{
    return (ch >= 'a' && ch <= 'z');
}

int main() 
{
    char ch;

    scanf("%c", &ch);

    if (my_isalnum(ch))
    {
        printf("Entered character is lower case alphabet\n");
    }
    else
    {
        printf("Entered character is not lower case alphabet\n");
    }

    return 0;
}