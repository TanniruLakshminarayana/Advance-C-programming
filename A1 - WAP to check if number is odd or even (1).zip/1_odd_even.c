/*
   Documentation
Name : T.Lakshminarayana
Date :01/02/2024
Title :WAP to check if number is odd or even
Sample input :Enter the value of 'n' : -2
              Enter the value of 'n' : 2
Sample output :-2 is negative even number
                2 is positive even number
*/

#include<stdio.h>
int main()
{
    int num;
    //Providing user input
    printf("Enter the value of 'num':");
    scanf("%d",&num);
    //Checking condition to print even or odd and it's sign
    if(num == 0)
    {
        printf("0 is neither odd nor even\n");
    }
    else
    {
        if(num % 2 == 0)
        {
            //Even numbers
            if (num > 0)
            {
               printf("%d is positive even number\n",num);
            }
            else
            {
               printf("%d is negative even number\n",num);
            }
        }
        else
        {
            //odd numbers
           if(num > 0)
           {
               printf("%d is positive odd number\n",num);
           }
           else
           {
               printf("%d is negative odd number\n",num);
           }
        }
    }
        //Exit successfully
  return 0;
}

