/*
   Documentation
Name : T.Lakshminarayana
Date :06/03/2024
Title :To generate the prime series upto the given limit using functions
Sample input :Enter a number: 2

Sample output :2
*/


#include <stdio.h>

int is_prime(int num)
{
    for(int i=2; i<=num/2; i++)
    {
        if(num%i==0)
        {
            return 0;
        }
    }
    return 1;
}



void generate_prime(int limit)
{
    for(int i=2; i<=limit; i++)
    {
        if(is_prime(i))
        {
            printf("%d ",i);
        }
    }
}


int main()
{
    int limit;

    printf("Enter the limit: ");
    scanf("%d", &limit);

    if (limit > 1)
    {
        generate_prime(limit);
    }
    else
    {
        printf("Invalid input\n");
    }

    return 0;
}