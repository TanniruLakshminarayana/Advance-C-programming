/*
   Documentation
Name : T.Lakshminarayana
Date :01/02/2024
Title : To print pyramid pattern as shown below
Sample input :Enter the number: 4
Sample output :
4
3 4
2 3 4
1 2 3 4
2 3 4
3 4
4
*/

#include <stdio.h>

int main() {
    int n, i, j;
    //Enter the user input
    printf("Enter the number: ");
    scanf("%d", &n);

    // Upper half of the pyramid
    for (i = n; i >= 1; i--) {
        for (j = i; j <= n; j++) {
            printf("%d ", j);
        }
        printf("\n");
    }

    // Lower half of the pyramid
    for (i = 2; i <= n; i++) {
        for (j = i; j <= n; j++) {
            printf("%d ", j);
        }
        printf("\n");
    }
    //Exit successfully
    return 0;
}
