/*
   Documentation
Name : T.Lakshminarayana
Date :10/04/2024
Title :To reverse the given string using recursive method
Sample input :Enter a string : Hello World
Sample output :Reverse string is : dlroW olleH
*/

#include <stdio.h>

void reverse_recursive(char str[], int ind, int len);

int main()
{
    char str[30];
        int len = 0;
        int ind = 0;


    scanf("%[^\n]", str);
        for(int i = 0; str[i] != '\0'; i++){
                len++;
        }
        len -= 1;

    reverse_recursive(str, ind, len);

    printf("Reversed string is %s\n", str);
}
void reverse_recursive(char str[], int ind, int len){
        if(len == (ind+len)/2){
                return;
        }
        char temp = str[ind];
        str[ind] = str[len];
        str[len] = temp;
        reverse_recursive(str, ind+1, len-1);
}
