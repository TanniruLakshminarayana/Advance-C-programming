/*
   Documentation
Name : T.Lakshminarayana
Date :04/03/2024
Title :To implement your own isxdigit() function
Sample input :Enter the character: a
Sample output :Entered character is an hexadecimal digit
*/


#include <stdio.h>
#include <ctype.h>

int is_xdigit(int ch)
{
    return (ch>='0' && ch<='9') || (ch>='a' && ch<='f') || (ch>='A' && ch<='F');
}

int main()
{
    char ch;

    printf("Enter the character: ");
    scanf("%c", &ch);

    if (is_xdigit(ch))
    {
        printf("Entered character is an hexadecimal digit\n");
    }
    else
    {
        printf("Entered character is not an hexadecimal digit\n");
    }

    return 0;
}